# Pijavski

This is an example of on how to use CFFI to call the Pijavski function written in C++ and test it with a sample function to optimise it and obtain the minimum.
